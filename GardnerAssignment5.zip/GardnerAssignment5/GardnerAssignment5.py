'''
Nick Gardner
Assignment 5 - Working With Dictionaries
Date: 2/12/18

Assignment:
1.  Create a text file containing a to do list.
2.  When the program loads, read each row of data from the text file into a dictionary
3.  Add the dictionary rows into a list
4.  Display the contents of the list to the user
5.  Give the user options to: view the data, to add or remove items, save the data, exit the program
'''

#Define variables
dicRow = {}
lstTable = []

#Read the lines from the file, place them into a dictionary, and add all to a list.
objFile = open("C:\\_PythonClass\\ToDo.txt", "r")
for line in objFile:
    dicRow = {"Job": (line.split(",")[0]).strip(), "Priority": (line.split(",")[1]).strip()}
    lstTable += dicRow,
objFile.close()

#Display the contest for the user.
print("Currently on your to do list: ")
for row in lstTable:
    print(row["Job"] + ', ' + row["Priority"])

#Give the user a menu of choices.  Allow them multiple choices until opting to exit.
while(True):
    print("\n Select an option: \n"
          "1) Show current data \n"
          "2) Add a new item \n"
          "3) Remove an existing item \n"
          "4) Save data to file \n"
          "5) Exit Program")
    strChoice = input("Which option would you like? 1 - 5: ") #Get user's choice

    #Choice 1 - Show current items
    if(strChoice == '1'):
        print('\n') #put a line between the menu and the output
        for row in lstTable:
            print(row["Job"] + ', ' + row["Priority"])

    #Choice 2 - Add a new item
    elif(strChoice == '2'):
        strJob = input("Enter a task you need to do: ") #get user inputs
        strPriority = input("What level of priority does this task have: ")
        dicRow = {"Job": strJob, "Priority": strPriority} #put inputs into dictionary

        lstTable += dicRow, #add task to the list

    #Choice 3 - Remove an existing item
    elif(strChoice == '3'):
        strRemove = input("Which task would you like to remove (case sensitive): ") #get user input
        for row in lstTable:
            if strRemove in row.values(): #find the dictionary entry with the given task
                lstTable.remove(row) #remove the dictionary entry with that task

    #Choice 4 - Save data to file
    elif(strChoice == '4'):
        objFile = open("C:\\_PythonClass\\ToDo.txt", "w")
        for item in lstTable:
            objFile.write(item["Job"] + ', ' + item["Priority"] + '\n')
        objFile.close()

    #Choice 5 - Exit
    elif(strChoice == '5'): break #leave the while loop

print('goodbye') #sign-off