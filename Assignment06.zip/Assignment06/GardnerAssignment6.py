'''
Nick Gardner
Assignment 6 - Functions and Classes
Date: 2/19/18

Assignment:
1.  Create a text file containing a to do list.
2.  Make a function that loads the rows of data into a python dictionary
3.  Add the dictionary rows to a python list.
4.  Make a function that displays the list contents to the user
5.  Make a function that allows the user to add or remove tasks from the list
6.  Make a function that saves the tasks/ priorities,
7.  Make a function to save the list and exit the program
'''


# --data--
objFileName = "C:\\_PythonClass\\ToDo.txt" #name of the text file
dicRow = {} #a row from the file converted into a dictionary element
lstTable = [] #the list holding all dictionary items
strChoice = None #the user's choice for operation to perform

# --processing--

class ListProcesses(object):
    '''The class contains methods for manipulating the ToDo.txt file'''

    @staticmethod
    def ReadFile(objFile):
        '''A function that takes rows from the text file and places them in a dictionary/list'''
        objFile = open(objFileName, "r")
        global lstTable
        for line in objFile:
            if not line.isspace(): #ignore lines that are blank space
                dicRow = {"Job": (line.split(",")[0]).strip(), "Priority": (line.split(",")[1]).strip()}
                lstTable += dicRow,
        objFile.close()

    @staticmethod
    def ListTasks(lst1):
        '''Displays the current list to the user'''
        print("Currently on your to do list: ")
        for row in lst1:
            print(row["Job"] + ', ' + row["Priority"])

    @staticmethod
    def AddItem(strJob, strPriority):
        '''Adds user's given Job and Priority to the list'''
        dicRow = {"Job": strJob, "Priority": strPriority}  # put inputs into dictionary
        global lstTable
        lstTable += dicRow, #add dictionary to the list

    @staticmethod
    def RemoveItem(strRemove):
        '''Remove the user's given Job from the list'''
        global lstTable
        for row in lstTable:
            if strRemove in row.values():  # find the dictionary entry with the given task
                lstTable.remove(row)  # remove the dictionary entry with that task

    @staticmethod
    def SaveList(objFile):
        '''Save the list to the file without exiting'''
        objFile = open(objFileName, "w")
        global lstTable
        for item in lstTable:
            objFile.write(item["Job"] + ', ' + item["Priority"] + '\n')
        objFile.close()

# --presentation--

ListProcesses.ReadFile(objFileName) #read the ToDo.txt file

ListProcesses.ListTasks(lstTable) #display the starting contents of the file to the user

#Give the user a menu of choices.  Allow them multiple choices until opting to exit.
while(True):
    print("\n Select an option: \n"
          "1) Show current data \n"
          "2) Add a new item \n"
          "3) Remove an existing item \n"
          "4) Save data to file \n"
          "5) Exit Program")
    strChoice = input("Which option would you like? 1 - 5: ") #Get user's choice

    #Choice 1 - Show current item
    if(strChoice == '1'):
        ListProcesses.ListTasks(lstTable) #call the function to list the tasks

    #Choice 2 - Add a new item
    elif(strChoice== '2'):
        strJob = input("Enter a task you need to do: ")  # get user inputs
        strPriority = input("What level of priority does this task have: ")
        ListProcesses.AddItem(strJob, strPriority) #call the function to add the given task

    #Choice 3 = Remove an item
    elif(strChoice == '3'):
        strRemove = input("Which task would you like to remove (case sensitive): ")  # get user input
        ListProcesses.RemoveItem(strRemove) #call the function to remove the given task

    #Choice 4 - Save data to the file and do not exit
    elif(strChoice == '4'):
        ListProcesses.SaveList(objFileName) #call the function to save the list to file

    #Choice 5 - Save data to the file and exit
    elif(strChoice == '5'):
        ListProcesses.SaveList(objFileName)
        break #leave the loop

    #Nonvalid entry - restart the loop
    else: print('Please enter an integer 1 - 5')

print('goodbye') #sign-off


